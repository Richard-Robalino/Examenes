
function cargarproyectos() {
    var proyectos = JSON.parse(localStorage.getItem('proyectos'));
    var proyectosContainer = document.getElementById('proyectosContainer');

    if (proyectos && proyectos.length > 0) {
        proyectos.forEach(function (proyecto) {
            var proyectoDiv = document.createElement('div');
            proyectoDiv.innerHTML = '<h3>' + proyecto.title + '</h3>' +
                '<p><strong>Descripción:</strong> ' + proyecto.description + '</p>' +
                '<p><strong>Enlace:</strong> <a href="' + proyecto.link + '">' + proyecto.link + '</a></p>';
            proyectosContainer.appendChild(proyectoDiv);
        });
    }
}
cargarproyectos();
