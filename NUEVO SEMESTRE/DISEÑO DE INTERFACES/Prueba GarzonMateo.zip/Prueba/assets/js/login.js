document.getElementById('login-form').addEventListener('submit', function(event) { 
    event.preventDefault();
    var email = document.getElementById('email').value;
    var password = document.getElementById('password').value;
    if (email = "mateo@garzon" && password == 123456) {

        window.location.href = 'login2.html';
    } else {

        alert('Usuario o contraseña incorrectos');
    }
});