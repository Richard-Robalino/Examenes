function toggleForm(type) {
    var proyecto = document.querySelector('.proyecto-form');
    var habilidades = document.querySelector('.habilidades-form');
    

    if (type === 'proyecto') {
        proyecto.style.display = 'block';
        habilidades.style.display = 'none';
    } else if (type === 'habilidad') {
        proyecto.style.display = 'none';
        habilidades.style.display = 'block';
    }
}

function guardarproyectos() {
    var title = document.getElementById('proyecto-titulo').value;
    var description = document.getElementById('proyecto-descripcion').value;
    var link = document.getElementById('proyecto-link').value;
    var proyecto = {
        title: title,
        description: description,
        link: link
    };
    var proyectos = JSON.parse(localStorage.getItem('proyectos')) || [];
    proyectos.push(proyecto);
    localStorage.setItem('proyectos', JSON.stringify(proyectos));
    window.location.href = 'index.html';
}
function guardarhabilidad(){
    var habilidade = document.getElementById('habilidades-nombre').value
    var descripcionhabilidad = document.getElementById('habilidades-descripcion').value
    var habilidad ={
        habilidade: habilidade,
        descripcionhabilidad:descripcionhabilidad
    }
    var habilidades = JSON.parse(localStorage.getItem('habilidad'))|| [];
    habilidades.push(habilidad)
    localStorage.setItem('habilidades',JSON.stringify(habilidades));
    window.location.href = 'index.html';
}