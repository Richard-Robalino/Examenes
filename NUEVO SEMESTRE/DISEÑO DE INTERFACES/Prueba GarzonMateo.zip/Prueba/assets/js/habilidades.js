function cargarhabilidades() {
    var habilidades = JSON.parse(localStorage.getItem('habilidades'))
    var habilidadesContainer = document.getElementById('habilidadesContainer');
    if (habilidades && habilidades.length > 0) { 
        habilidades.forEach(function (habilidad) {
            var habilidadDiv = document.createElement('div');
            habilidadDiv.innerHTML = '<h3>' + habilidad.habilidade + '</h3>' + 
                '<p><strong>Descripción:</strong> ' + habilidad.descripcionhabilidad + '</p>';
            habilidadesContainer.appendChild(habilidadDiv);
        });

    }
}
cargarhabilidades();
